package edu.ntnu.apputvikling.leksjon2

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        const val REQUEST_CODE_RANDOM_NUMBERS = 1001
    }

    private lateinit var resultTextView: TextView
    private lateinit var textViewNumber1: TextView
    private lateinit var textViewNumber2: TextView
    private lateinit var editTextAnswer: EditText
    private lateinit var editTextUpperLimit: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupViews()
    }

    private fun setupViews() {
        resultTextView = findViewById(R.id.resultTextView)
        textViewNumber1 = findViewById(R.id.textViewNumber1)
        textViewNumber2 = findViewById(R.id.textViewNumber2)
        editTextAnswer = findViewById(R.id.editTextAnswer)
        editTextUpperLimit = findViewById(R.id.editTextUpperLimit)

        findViewById<Button>(R.id.button_start_random_activity).setOnClickListener { updateNumbers() }
        findViewById<Button>(R.id.buttonAddition).setOnClickListener { performOperation(Operation.ADDITION) }
        findViewById<Button>(R.id.buttonMultiplication).setOnClickListener { performOperation(Operation.MULTIPLICATION) }

        updateNumbers()
    }

    private fun updateNumbers() {
        val upperLimit = editTextUpperLimit.text.toString().toIntOrNull() ?: 100
        startRandomNumberActivity(upperLimit)
    }

    private fun startRandomNumberActivity(maxValue: Int) {
        val intent = Intent(this, RandomNumberActivity::class.java).apply {
            putExtra("MAX_VALUE", maxValue)
            putExtra("GENERATE_TWO_NUMBERS", true)
        }
        startActivityForResult(intent, REQUEST_CODE_RANDOM_NUMBERS)
    }

    private fun performOperation(operation: Operation) {
        val number1 = textViewNumber1.text.toString().toIntOrNull() ?: 0
        val number2 = textViewNumber2.text.toString().toIntOrNull() ?: 0
        val userAnswer = editTextAnswer.text.toString().toIntOrNull()

        val correctAnswer = when (operation) {
            Operation.ADDITION -> number1 + number2
            Operation.MULTIPLICATION -> number1 * number2
        }

        if (userAnswer == correctAnswer) {
            Toast.makeText(this, getString(R.string.riktig), Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, getString(R.string.feil_svar, correctAnswer), Toast.LENGTH_SHORT).show()
        }

        updateNumbers()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_RANDOM_NUMBERS && resultCode == RESULT_OK) {
            val number1 = data?.getIntExtra("RANDOM_NUMBER_1", -1) ?: -1
            val number2 = data?.getIntExtra("RANDOM_NUMBER_2", -1) ?: -1

            textViewNumber1.text = number1.toString()
            textViewNumber2.text = number2.toString()
            updateGeneratedNumbersDisplay(number1, number2)
        }
    }

    private fun updateGeneratedNumbersDisplay(number1: Int, number2: Int) {
        resultTextView.text = getString(R.string.generated_numbers, number1, number2)
    }

    enum class Operation {
        ADDITION, MULTIPLICATION
    }
}