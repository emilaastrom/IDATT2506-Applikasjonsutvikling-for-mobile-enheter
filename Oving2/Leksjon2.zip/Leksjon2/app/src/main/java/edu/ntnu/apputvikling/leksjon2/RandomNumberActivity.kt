package edu.ntnu.apputvikling.leksjon2

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

class RandomNumberActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val maxValue = intent.getIntExtra("MAX_VALUE", 100)
        val generateTwoNumbers = intent.getBooleanExtra("GENERATE_TWO_NUMBERS", false)

        val number1 = (0..maxValue).random()
        val number2 = if (generateTwoNumbers) (0..maxValue).random() else -1

        /*Toast.makeText(this, "Generert tilfeldig tall 1: $number1", Toast.LENGTH_SHORT).show()

        if (generateTwoNumbers) {
            Toast.makeText(this, "Generert tilfeldig tall 2: $number2", Toast.LENGTH_SHORT).show()
        }*/

        val resultIntent = Intent().apply {
            putExtra("RANDOM_NUMBER_1", number1)
            putExtra("RANDOM_NUMBER_2", number2)
        }
        setResult(RESULT_OK, resultIntent)
        finish()
    }
}